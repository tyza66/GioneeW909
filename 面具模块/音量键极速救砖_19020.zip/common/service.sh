#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}
modulesParent=$(dirname $MODDIR)
# 该脚本将在设备开机后作为延迟服务启动
sleep 1
if [ "$modulesParent" = "" ]; then
  modulesParent=/data/adb/modules
fi
keyCheckPath=${MODDIR}/system/etc/keycheck
checkEnableApps=${MODDIR}/.enable_apps
chmod 0777 $keyCheckPath
#ModulesParent=/data/adb/modules
$keyCheckPath
$keyCheckPath
$keyCheckPath
if [[ $(getprop init.svc.bootanim) == "stopped" ]]; then
  echo "正常开机，发生时间：$(date "+%Y年%m月%d日%H:%M:%S")" >>${MODDIR}/Log.txt
  if [ -f $checkEnableApps ]; then
    rm -rf "$checkEnableApps"
  fi
else
  touch "/cache/.disable_magisk"
  if [ -f $checkEnableApps ]; then
    rm -rf "$checkEnableApps"
    rm -rf /data/system/users/0/package-restrictions.xml
  else
    touch "$checkEnableApps"
  fi
  for path in $(ls $modulesParent); do
    if [ "$path" != "RescueBrick" ]; then
      touch "$modulesParent/$path/disable"
    fi
  done

  echo "开机失败，发生时间：$(date "+%Y年%m月%d日%H:%M:%S")" >>"${MODDIR}"/Log.txt
  reboot

fi
