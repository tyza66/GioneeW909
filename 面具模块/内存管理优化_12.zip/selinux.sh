#!/system/bin/sh
#编写作者：@coolapk 10007
#gitee主页https://gitee.com/keytoolazy/mapdepot

id="$id"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
local_MODPATH="/data/adb/$Magisk_mod/$id"

function get_log(){
local name="$1"
local file="$2"
if test -f "$file" ;then
	if test -z "$name" ;then
		cat "$file" | grep -oi "avc.*permissive" | sort | uniq
	else
		cat "$file" | grep -w -i "$name" | grep -oi "avc.*permissive" | sort | uniq
	fi
else
	if test -z "$name" ;then
		dmesg | grep -oi "avc.*permissive" | sort | uniq
	else
		dmesg | grep -w -i "$name" | grep -oi "avc.*permissive" | sort | uniq
	fi
fi
}

function get_scontext(){
local text="$1"
echo "$text" | grep -Eo "scontext=.*s0" | cut -d':' -f3 | sed 's/[[:space:]]//g'
}

function get_tcontext(){
local text="$1"
echo "$text" | grep -Eo "tcontext=.*s0" | cut -d':' -f3 | sed 's/[[:space:]]//g'
}


function get_tclass(){
local text="$1"
echo "$text" | grep -Eo "tclass=.*permissive" | cut -d'=' -f2 | sed 's|permissive.*||g'
}

function get_denied(){
local text="$1"
echo "$text" | grep -Eo "denied.*}" | sed 's|denied||g'
}

function running_main(){
local IFS=$'\n'
local selinux_rules="$1.Verbose"
local name="$2"
local file="$3" 
for i in $(get_log "$name" "$file")
do
cat <<key >> "$selinux_rules"
#log `date '+%F %T'` [ $i ]
allow $(get_scontext "$i") $(get_tcontext "$i") $(get_tclass "$i") $(get_denied "$i")
key
done
test -f "$selinux_rules" && {
cat <<key >>"${selinux_rules%/*}/sepolicy.rule"
#`date '+%F %T'`
`cat "$selinux_rules" | sed '/^#/d;/^[[:space:]]*$/d;s|   | |g;s|  | |g' | sort | uniq`
key
	}
}

running_main "$MODPATH/sepolicy.rule" "servicemanager"
running_main "$MODPATH/sepolicy.rule" "activitymanager"
running_main "$MODPATH/sepolicy.rule" "swappiness"
running_main "$MODPATH/sepolicy.rule" "lmkd"

test -f "$local_MODPATH/sepolicy.rule" && {
echo "$(cat $local_MODPATH/sepolicy.rule)" >> "$MODPATH/sepolicy.rule"
echo "$(cat $MODPATH/sepolicy.rule | sort | uniq | sed '/^#/d' )" > "$MODPATH/sepolicy.rule"
}