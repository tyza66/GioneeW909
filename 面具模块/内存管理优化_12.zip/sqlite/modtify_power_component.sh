#!/system/bin/sh

export PATH="${0%/*}:/system/bin":$PATH

function running_main(){
local sate="$1"
local list="
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
"
for i in $list ;do
	pm "$sate" "$i" >/dev/null 2>1
done
}

#enable 启用
#disable 禁用
running_main "disable"

#修改IFW文件
local file='/data/system/ifw/com.miui.powerkeeper$.xml'
mkdir -p "${file%/*}"
test ! -f "$file" && cp -rf "${0%/*}/com.miui.powerkeeper$.xml" /data/system/ifw


