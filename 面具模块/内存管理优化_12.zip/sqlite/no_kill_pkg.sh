#!/system/bin/sh

export PATH="${0%/*}:/system/bin":$PATH

local file="/data/data/com.miui.securitycenter/databases/cloud_no_kill_pkg.db"

function echo_kill_pkg(){
sqlite3 "$file" << EOF
select pkg_name from no_kill_pkg ; 
EOF
}

function no_kill_pkg(){
for i in $(pm list package -3 | sed 's|package:||g' )
do
if test "$(echo "$(echo_kill_pkg)" | grep -w "$i")" = "" ;then
sqlite3 "$file" << EOF
insert into no_kill_pkg (pkg_name) values("$i");
EOF
else
	continue
fi
done
}

no_kill_pkg




