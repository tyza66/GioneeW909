#test

function running_main(){
local sate="$1"
local list="
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
"
for i in $list ;do
	pm "$sate" "$i" >/dev/null 2>1
done
}

#enable 启用
#disable 禁用
running_main "enable"
file='/data/system/ifw/com.miui.powerkeeper$.xml'
test -f "$file" && rm -rf "$file"

