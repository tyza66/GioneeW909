

if test "$(getprop ro.miui.ui.version.name )" = "" ;then 
	rm -rf "$MODPATH/sqlite"
fi

function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

if test "$(show_value "自动内存回收")" != "开启" ;then
	rm -rf "$MODPATH/crond"
	rm -rf "$MODPATH/busybox.sh"
fi


