#!/system/bin/sh
#由@coolapk 10007编写
#模块数据来源网络和本人修改。


source "${0%/*}/util_functions.sh"

#尝试禁用内存整理
function disable_trimmer(){
local value="$1"
local number="0"
if test -z "$value" ;then 
	cmd device_config put activity_manager trim_cached_processes "$number"
		cmd settings put global activity_manager_constants trim_cached_processes="$number"
			cmd device_config put activity_manager trim_empty_processes "$number"
				cmd settings put global activity_manager_constants trim_empty_processes="$number"
				device_config put activity_manager trim_cached_processes "$number"
			settings put global activity_manager_constants trim_cached_processes="$number"
		device_config put activity_manager trim_empty_processes "$number"
	settings put global activity_manager_constants trim_empty_processes="$number"
fi
}

#设置更多的缓存和进程
function more_cached_apps(){
	local number="$1"
	test "$(echo $number | grep [0-9])" = "" && number="128"
	cmd device_config put activity_manager max_cached_processes "$number"
		cmd settings put global activity_manager_constants max_cached_processes="$number"
			cmd device_config put activity_manager max_empty_processes "$number"
				cmd settings put global activity_manager_constants max_empty_processes="$number"
			device_config put activity_manager max_cached_processes "$number"
				settings put global activity_manager_constants max_cached_processes="$number"
		device_config put activity_manager max_empty_processes "$number"
	settings put global activity_manager_constants max_empty_processes="$number"
	if test "$(getprop ro.system.build.version.sdk)" -gt "30" ;then 
		cmd device_config set_sync_disabled_for_tests persistent
			cmd device_config put activity_manager max_phantom_processes 2147483647
				device_config set_sync_disabled_for_tests persistent
				device_config put activity_manager max_phantom_processes 2147483647
			cmd settings put global activity_manager_constants max_phantom_processes=2147483647
		settings put global activity_manager_constants max_phantom_processes=2147483647
	fi
}

if test "$(show_value "后台活动管理")" = "修改" ;then
	more_cached_apps "2147483647"
	disable_trimmer
fi
