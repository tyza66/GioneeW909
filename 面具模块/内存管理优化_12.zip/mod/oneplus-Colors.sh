#!/system/bin/sh
#由@coolapk 10007编写
#模块数据来源网络和本人修改。

source "${0%/*}/util_functions.sh"

#禁用一加/OPPO的内存管理
function one_plus_tune(){
	resetprop persist.vendor.sys.memplus.enable false || setprop persist.vendor.sys.memplus.enable false 
	set_value "0" /sys/module/memplus_core/parameters/memory_plus_enabled
	set_value "0" /proc/sys/vm/memory_plus
	set_value "0" /sys/module/lowmemorykiller/parameters/batch_kill
	set_value "0" /sys/module/lowmemorykiller/parameters/quick_select
	set_value "0" /sys/module/lowmemorykiller/parameters/time_measure
	set_value "N" /sys/module/lowmemorykiller/parameters/trust_adj_chain
	set_value "0" /proc/sys/vm/breath_period
	set_value "-1001" /proc/sys/vm/breath_priority
	resetprop persist.vendor.sys.memplus.enable false || setprop persist.vendor.sys.memplus.enable false 
}

if test $(show_value "一加内存管理") == 关闭 ;then
	one_plus_tune
fi