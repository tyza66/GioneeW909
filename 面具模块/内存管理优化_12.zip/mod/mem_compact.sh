#!/system/bin/sh
#来自于@coolapk 嘟嘟司机(scene 开发者)
#开机强制进行内存回收

#等待开机5分钟后，启动回收
#sleep 5m

#清空缓存
echo '3' > /proc/sys/vm/drop_caches

if test -f '/proc/sys/vm/extra_free_kbytes' ;then
	modify_path='/proc/sys/vm/extra_free_kbytes'
	friendly=true
elif test -f '/proc/sys/vm/min_free_kbytes' ;then
	modify_path='/proc/sys/vm/min_free_kbytes'
else
	echo '搞不定，你这内核不支持！'
	return 1
fi


min_free_kbytes=`cat $modify_path`
setprop ro.key.compact_memory $min_free_kbytes

MemTotalStr=`cat /proc/meminfo | grep MemTotal`
MemTotal=${MemTotalStr:16:8}

MemMemFreeStr=`cat /proc/meminfo | grep MemFree`
MemMemFree=${MemMemFreeStr:16:8}

SwapFreeStr=`cat /proc/meminfo | grep SwapFree`
SwapFree=${SwapFreeStr:16:8}

if test "$friendly" = "true" ;then
	TargetRecycle=$(($MemTotal / 100 * 55))
else
	TargetRecycle=$(($MemTotal / 100 * 26))
fi

# 如果可用内存大于目标可用内存大小，则不需要回收了
if test $MemMemFree -gt $TargetRecycle ;then
	echo '内存充足，不需要操作！'
else
	# 计算需要回收多少内存
	RecyclingSize=$(($TargetRecycle - $MemMemFree))
	# 计算回收这些内存需要消耗的SWAP容量
	SwapRequire=$(($RecyclingSize / 100 * 130))
	# 如果没有足够的Swap容量可以回收这些内存
	# 则只拿Swap剩余容量的50%来回收内存
	if test $SwapFree -lt $SwapRequire ;then
		RecyclingSize=$(($SwapFree / 100 * 50))
	fi
	# 最后计算出最终要回收的内存大小
	TargetRecycle=$(($RecyclingSize + $MemMemFree))
	if test $RecyclingSize != "" -a $RecyclingSize -gt 0 ; then
		echo $TargetRecycle > $modify_path
	sleep_time=$(($RecyclingSize / 1024 / 60 + 2))
		while test $sleep_time -gt 0 
		do
		sync
			sleep 1
			MemMemFreeStr=`cat /proc/meminfo | grep MemFree`
			MemMemFree=${MemMemFreeStr:16:8}
			test "$(($TargetRecycle - $MemMemFree))" -lt "100" && break
			SwapFreeStr=`cat /proc/meminfo | grep SwapFree`
			SwapFree=${SwapFreeStr:16:8}
			test $SwapFree -lt 100 && break
			sleep_time=$(($sleep_time - 1))
		done
		echo $(getprop ro.key.compact_memory) > $modify_path
		sync
	else
		echo '操作失败，计算容量出错!'
	fi
fi

echo 1 > /proc/sys/vm/compact_memory
