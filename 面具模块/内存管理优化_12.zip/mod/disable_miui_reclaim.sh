#!/system/bin/sh
#由@coolapk 10007编写
#模块数据来源网络和本人修改。


source "${0%/*}/util_functions.sh"

#禁用mi_reclaim
#来自于@coolapk 嘟嘟司机(scene 开发者)
function dis_mi_reclaim() {
	#禁用mi_reclaim
	set_value 0 /sys/kernel/mi_reclaim/enable

	#尝试禁用小米的rtmm
	if test -d '/d/rtmm' ;then
		mi_rtmm=/d/rtmm/reclaim
	elif test -d '/sys/kernel/mm/rtmm' ;then
		mi_rtmm='/sys/kernel/mm/rtmm'
	else
		return
	fi

	set_perm $mi_rtmm/reclaim/auto_reclaim root root 000
	set_perm $mi_rtmm/reclaim/global_reclaim root root 000
	set_perm $mi_rtmm/reclaim/proc_reclaim root root 000
	set_perm $mi_rtmm/reclaim/kill root root 000
	set_perm $mi_rtmm/compact/compact_memory root root 000

}

#去掉注释即可启用
if test $(show_value "MIUI回收内存碎片") == 关闭 ;then
	dis_mi_reclaim
fi


