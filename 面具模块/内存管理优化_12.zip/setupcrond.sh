#!/system/bin/sh

#crond配置文件
crond_file="$MODPATH/crond/root"

test ! -d "${crond_file%/*}" && return 0

#模块变量
id="$id"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
key_MODPATH="/data/adb/$Magisk_mod/$id"

#为每个脚本写入变量和crond配置文件
for i in $MODPATH/crond/*.sh
do
name="${i##*/}"
sed -i "1i #!/system/bin/sh" "$i"
sed -i "2i #@coolapk 1007" "$i"
sed -i "3i MODPATH="$key_MODPATH"" "$i"
sed -i "4i export PATH=\$MODPATH/busybox:\$(magisk --path)/.magisk/busybox:\$PATH" "$i"
cat <<key >> $crond_file
*/3 * * * * $key_MODPATH/crond/$name
key
done




