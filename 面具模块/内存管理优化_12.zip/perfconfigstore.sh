#!/system/bin/sh

function correctpath() {
	case $(echo "$1") in
	/system*)
		echo "$1"
	;;
	/*)
		echo "/system"$1""
	;;
	esac
}



function Disable_old_value() {
	local file="$1"
	for value in $(cat $MODPATH/system.prop 2>/dev/null | sed 's|\=.*||g;/^\#/d;/^[[:space:]]*$/d' )
	do
		sed -i "/$value/d" "$file"
	done
}


function mk_pfer_file() {
	find /system /product /vendor /system_ext -iname "perfconfigstore.xml" -type f 2> /dev/null | while read file ;do
	target=$(correctpath "$file" )
	mkdir -p "$MODPATH${target%/*}"
	cp -rf "$file" "$MODPATH$target"
	Disable_old_value "$MODPATH$target"
done || echo "- 不存在perfconfigstore.xml文件！"
}



qualcomm_prop=`getprop | egrep -w "qualcomm|qti" | wc -l`
qualcomm_package=`pm list package -s | egrep -w "qualcomm|qti" | wc -l`
if test $qualcomm_prop -lt 1 -a $qualcomm_package -lt 1 ;then 
	echo "- 非高通骁龙设备！跳过修改perfconfigstore.xml !"
else 
	mk_pfer_file
fi



